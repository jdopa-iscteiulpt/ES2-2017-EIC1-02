package mt.exception;

public class AuthenticationException extends Exception {

	public AuthenticationException(String error) {
		super(error);
	}

}
