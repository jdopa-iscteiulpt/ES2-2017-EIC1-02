package mt.client.exception;

public class AuthenticationException extends Exception {

	public AuthenticationException(String error) {
		super(error);
	}

}
